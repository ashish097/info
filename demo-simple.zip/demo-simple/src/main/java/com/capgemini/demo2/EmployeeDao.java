package com.capgemini.demo2;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

public class EmployeeDao {

	/*
	public List<Employee> findbyNameUsingCriteria (String name) {
		Session session= HibernateUtil.getSessionFactory().getCurrentSession();
		try{
		 session.beginTransaction();
		 Criteria crit = session.createCriteria(Employee.class);
		 crit.createAlias("name","emp.name");
		 crit.add(Restrictions.eq("emp.name",name));
		 //crit.add(Restrictions.eq("name",name));
		 List<Employee> emplist = crit.list();      
		 session.getTransaction().commit();	
		 return emplist;
		}catch(Exception ex)
		{   System.out.println(ex);
			session.getTransaction().rollback();
			return null;
		}		
		
	}
	*/
	
	public List<Object[]> findIdAndNameForAllEmployee () {
		Session session= HibernateUtil.getSessionFactory().getCurrentSession();
		try{
		 session.beginTransaction();
		 Query query=session.createQuery("select id, name from Employee ");     
		 List<Object[]> emplist = query.list();      
		 session.getTransaction().commit();	
		 return emplist;
		}catch(Exception ex)
		{   System.out.println(ex);
			session.getTransaction().rollback();
			return null;
		}		
		
	}
	
	
	
	public List<Employee> findAllEmployee () {
		Session session= HibernateUtil.getSessionFactory().getCurrentSession();
		try{
		 session.beginTransaction();
		 Query query=session.createQuery("FROM Employee E order by E.salary desc");     
		 List<Employee> emplist = query.list();      
		 session.getTransaction().commit();	
		 return emplist;
		}catch(Exception ex)
		{   System.out.println(ex);
			session.getTransaction().rollback();
			return null;
		}		
		
	}
	
	
public List<Employee> findbyName (String name) {
	Session session= HibernateUtil.getSessionFactory().getCurrentSession();
	try{
	 session.beginTransaction();
	 Query query=session.createQuery("FROM Employee E WHERE E.name ='"+name+"'");     
	 List<Employee> emplist = query.list();      
	 session.getTransaction().commit();	
	 return emplist;
	}catch(Exception ex)
	{   System.out.println(ex);
		session.getTransaction().rollback();
		return null;
	}		
	
}

public List<Employee> findEmpHavingHigherSalary (int salary) {
	Session session= HibernateUtil.getSessionFactory().getCurrentSession();
	try{
	 session.beginTransaction();
	 Query query=session.createQuery("FROM Employee E WHERE E.salary >:sal");
	 query.setInteger("sal", salary) ;
	 List<Employee> emplist = query.list();      
	 session.getTransaction().commit();	
	 return emplist;
	}catch(Exception ex)
	{   System.out.println(ex);
		session.getTransaction().rollback();
		return null;
	}		
	
}

public Employee getEmployeeById(int emp_id) {
	Session session= HibernateUtil.getSessionFactory().getCurrentSession();
	try{
	 session.beginTransaction();
	 Employee emp=(Employee) session.get(Employee.class,new Integer(emp_id));
	 session.getTransaction().commit();	
	 return emp;
	}catch(Exception ex)
	{   System.out.println(ex);
		session.getTransaction().rollback();
		return null;
	}		
}

public Employee deleteEmployeeById(int emp_id) {
	Session session= HibernateUtil.getSessionFactory().getCurrentSession();
	try{
	 session.beginTransaction();
	 Employee emp=(Employee) session.get(Employee.class,new Integer(emp_id));
	 session.delete(emp);
	 session.getTransaction().commit();	
	 return emp;
	}catch(Exception ex)
	{   System.out.println(ex);
		session.getTransaction().rollback();
		return null;
	}		
}


public Employee giveBonus(int emp_id, int bonus) {
	
	
	Session session= HibernateUtil.getSessionFactory().getCurrentSession();
	try{
	 session.beginTransaction();
	 Employee emp=(Employee) session.get(Employee.class,new Integer(emp_id));
	 emp.setSalary(emp.getSalary()+ bonus);
	 session.getTransaction().commit();	
	 return emp;
	}catch(Exception ex)
	{   System.out.println(ex);
		session.getTransaction().rollback();
		return null;
	}
	
	
}


	
public Employee addEmployee(int emp_id, String name, int age, int salary) {
	
	Employee e= new Employee();
	e.setId(emp_id);
	e.setName(name);
	e.setAge(age);
	e.setSalary(salary);
	
	Session session= HibernateUtil.getSessionFactory().getCurrentSession();
	try{
	 session.beginTransaction();
	 session.save(e);
	 session.getTransaction().commit();	
	 return e;
	}catch(Exception ex)
	{   System.out.println(ex);
		session.getTransaction().rollback();
		return null;
	}
}
}
