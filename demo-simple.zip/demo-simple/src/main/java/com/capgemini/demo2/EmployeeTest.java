package com.capgemini.demo2;

import java.util.List;

import org.hibernate.Session;

public class EmployeeTest {
	
	public static void main(String[] args) {
      EmployeeDao  dao= new EmployeeDao();
      dao.addEmployee(1001,"Hari", 30, 3000);
      dao.addEmployee(1002,"Sunil", 40, 40000);
     
      /*
      Employee emp= dao.getEmployeeById(1001);
      System.out.println(emp);
      //change salary of employee with it 
      Employee emp1=dao.giveBonus(1001, 500);
      System.out.println(emp1);
      
      Employee emp3= dao.getEmployeeById(1002);
      System.out.println(emp3);
      dao.deleteEmployeeById(1002);
      Employee emp4= dao.getEmployeeById(1002);
      if (emp4==null) {
    	  System.out.println("Employee deleted");
      }
    
      Employee emp4= dao.findbyName("Sunil").get(0);
      System.out.println(emp4);
        
     List<Employee> highSalaryEmployees= dao.findEmpHavingHigherSalary(4000);
     for (Employee  e : highSalaryEmployees) {
    	 System.out.println(e);
	  }
   
      
      List<Employee> empList= dao.findAllEmployee();
      for (Employee  e : empList) {
     	 System.out.println(e);
 	  }
     
      */
      List<Object[]> empobj=dao.findIdAndNameForAllEmployee();
      for (Object[] e : empobj) {
      	 System.out.println(e[0]);  //id
      	 System.out.println(e[1]);  //name
  	  }
        
      
      /*
      List<Employee> empobj=dao.findbyNameUsingCriteria("Sunil");
      for (Employee e : empobj) {
      	 System.out.println(e);  
      	 
  	  }
  	  */
      
	}

}
