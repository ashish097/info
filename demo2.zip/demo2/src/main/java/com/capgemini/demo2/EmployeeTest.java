package com.capgemini.demo2;

import org.hibernate.Session;

public class EmployeeTest {
	
	public static void main(String[] args) {
      EmployeeDao  dao= new EmployeeDao();
      dao.addEmployee(1001,"Hari", 30, 3000);
      dao.addEmployee(1002,"Sunil", 40, 40000);
      Employee emp= dao.getEmployeeById(1001);
      System.out.println(emp);
      //change salary of employee with it 
      Employee emp1=dao.giveBonus(1001, 500);
      System.out.println(emp1);
      
      Employee emp3= dao.getEmployeeById(1002);
      System.out.println(emp3);
      dao.deleteEmployeeById(1002);
      Employee emp4= dao.getEmployeeById(1002);
      if (emp4==null) {
    	  System.out.println("Employee deleted");
      }
	}

}
