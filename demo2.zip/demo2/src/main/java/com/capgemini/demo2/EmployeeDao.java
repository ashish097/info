package com.capgemini.demo2;

import org.hibernate.Session;

public class EmployeeDao {


public Employee getEmployeeById(int emp_id) {
	Session session= HibernateUtil.getSessionFactory().getCurrentSession();
	try{
	 session.beginTransaction();
	 Employee emp=(Employee) session.get(Employee.class,new Integer(emp_id));
	 session.getTransaction().commit();	
	 return emp;
	}catch(Exception ex)
	{   System.out.println(ex);
		session.getTransaction().rollback();
		return null;
	}		
}

public Employee deleteEmployeeById(int emp_id) {
	Session session= HibernateUtil.getSessionFactory().getCurrentSession();
	try{
	 session.beginTransaction();
	 Employee emp=(Employee) session.get(Employee.class,new Integer(emp_id));
	 session.delete(emp);
	 session.getTransaction().commit();	
	 return emp;
	}catch(Exception ex)
	{   System.out.println(ex);
		session.getTransaction().rollback();
		return null;
	}		
}


public Employee giveBonus(int emp_id, int bonus) {
	
	
	Session session= HibernateUtil.getSessionFactory().getCurrentSession();
	try{
	 session.beginTransaction();
	 Employee emp=(Employee) session.get(Employee.class,new Integer(emp_id));
	 emp.setSalary(emp.getSalary()+ bonus);
	 session.getTransaction().commit();	
	 return emp;
	}catch(Exception ex)
	{   System.out.println(ex);
		session.getTransaction().rollback();
		return null;
	}
	
	
}


	
public Employee addEmployee(int emp_id, String name, int age, int salary) {
	
	Employee e= new Employee();
	e.setId(emp_id);
	e.setName(name);
	e.setAge(age);
	e.setSalary(salary);
	
	Session session= HibernateUtil.getSessionFactory().getCurrentSession();
	try{
	 session.beginTransaction();
	 session.save(e);
	 session.getTransaction().commit();	
	 return e;
	}catch(Exception ex)
	{   System.out.println(ex);
		session.getTransaction().rollback();
		return null;
	}
}
}
